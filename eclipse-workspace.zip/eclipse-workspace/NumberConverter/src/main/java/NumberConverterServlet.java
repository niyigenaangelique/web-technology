import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;

@WebServlet("/convert")
public class NumberConverterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String decimalNumber = request.getParameter("decimalNumber");
        if (decimalNumber == null || decimalNumber.trim().isEmpty()) {
            out.println("<html><body>");
            out.println("<h1>Number Converter</h1>");
            out.println("<form method='get'>");
            out.println("Enter a decimal number: <input type='text' name='decimalNumber'>");
            out.println("<input type='submit' value='Convert'>");
            out.println("</form>");
            out.println("</body></html>");
        } else {
            int decNum = Integer.parseInt(decimalNumber);

            String binaryNumber = Integer.toBinaryString(decNum);
            String hexNumber = Integer.toHexString(decNum);
            String octalNumber = Integer.toOctalString(decNum);

            out.println("<html><body>");
            out.println("<h1>Number Converter</h1>");
            out.println("<table border='2'>");
            out.println("<tr><th>Base</th><th>Number</th><th>Result</th></tr>");
            out.println("<tr><td>Decimal</td><td>" + decimalNumber + "</td><td>" + decNum + "</td></tr>");
            out.println("<tr><td>Binary</td><td>1</td><td>" + binaryNumber + "</td></tr>");
            out.println("<tr><td>Hexadecimal</td><td>A</td><td>" + hexNumber.toUpperCase() + "</td></tr>");
            out.println("<tr><td>Octal</td><td>0</td><td>" + octalNumber + "</td></tr>");
            out.println("</table>");
            out.println("</body></html>");
        }
    }
}